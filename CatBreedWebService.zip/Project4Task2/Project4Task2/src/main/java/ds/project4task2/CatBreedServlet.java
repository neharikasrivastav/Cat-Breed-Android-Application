/**
 * Author: Neharika
 * AndrewID: nneharik
 * Last Modified: April 9, 2025
 *
 * Description:
 * This servlet handles GET requests for cat breed information.
 * Given a breed name, it queries TheCatAPI to retrieve details and an image.
 * If the request comes from an Android device, it logs metadata to MongoDB Atlas.
 *
 * Key Features:
 * - Handles both browser and Android-based queries.
 * - Fetches breed metadata and image from TheCatAPI.
 * - Logs request metadata to MongoDB only for mobile devices.
 * - Returns a structured JSON response.
 */

package ds.project4task2;

import com.mongodb.client.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;

@WebServlet("/cat")
public class CatBreedServlet extends HttpServlet {

    // API key for TheCatAPI
    private static final String CAT_API_KEY = "live_BAV5sgirdg1i6ZE2GwQiVhWzz6wo7Ch8nL82culKCF8LY81aBj8qbBo8zIXfSVdf";

    // MongoDB Atlas connection string
    private static final String MONGO_URI = "mongodb+srv://nneharik:testing098123@advice-app-cluster.j4xd0.mongodb.net/?retryWrites=true&w=majority&appName=advice-app-cluster";

    // MongoDB collection for logging
    private MongoCollection<Document> logCollection;

    /**
     * Initializes the servlet and sets up MongoDB client/collection.
     */
    @Override
    public void init() throws ServletException {
        MongoClient mongoClient = MongoClients.create(MONGO_URI);
        MongoDatabase database = mongoClient.getDatabase("CatApp");
        logCollection = database.getCollection("logs");
        System.out.println(">> MongoDB initialized.");
    }

    /**
     * Handles GET requests to /cat.
     *
     * @param request  HttpServletRequest object containing breed query.
     * @param response HttpServletResponse object to send JSON result or error.
     * @throws IOException for input/output exceptions.
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String breedName = request.getParameter("breed");
        String phoneModel = request.getHeader("phone-model"); // Custom header from Android
        String userAgent = request.getHeader("User-Agent");   // For browser detection
        long startTime = System.currentTimeMillis();

        System.out.println(">> Received GET request at /cat with breed = " + breedName);

        // Handle missing breed input
        if (breedName == null || breedName.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing 'breed' parameter.");
            return;
        }

        // Determine if request is from mobile and log accordingly
        String deviceModel = "Desktop (Browser)";
        boolean shouldLog = false;

        if (phoneModel != null && !phoneModel.isEmpty()) {
            deviceModel = phoneModel;
            shouldLog = true;
        } else if (userAgent != null && userAgent.toLowerCase().contains("android")) {
            deviceModel = "Android (User-Agent)";
            shouldLog = true;
        }

        JSONObject breedInfo;
        String imageUrl = null;
        int catApiStatus = 0;

        try {
            // 1. Fetch breed information
            String searchUrl = "https://api.thecatapi.com/v1/breeds/search?q=" + breedName;
            HttpURLConnection breedConn = (HttpURLConnection) new URL(searchUrl).openConnection();
            breedConn.setRequestMethod("GET");
            breedConn.setRequestProperty("x-api-key", CAT_API_KEY);
            catApiStatus = breedConn.getResponseCode();

            BufferedReader in = new BufferedReader(new InputStreamReader(breedConn.getInputStream()));
            StringBuilder breedJson = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) breedJson.append(line);
            in.close();

            JSONArray breeds = new JSONArray(breedJson.toString());

            // Breed not found
            if (breeds.length() == 0) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Breed not found.");
                return;
            }

            breedInfo = breeds.getJSONObject(0);
            String breedId = breedInfo.getString("id");

            // 2. Fetch image using breed ID
            String imageUrlApi = "https://api.thecatapi.com/v1/images/search?breed_ids=" + breedId;
            HttpURLConnection imgConn = (HttpURLConnection) new URL(imageUrlApi).openConnection();
            imgConn.setRequestMethod("GET");
            imgConn.setRequestProperty("x-api-key", CAT_API_KEY);

            BufferedReader imgIn = new BufferedReader(new InputStreamReader(imgConn.getInputStream()));
            StringBuilder imgJson = new StringBuilder();
            while ((line = imgIn.readLine()) != null) imgJson.append(line);
            imgIn.close();

            JSONArray imageArr = new JSONArray(imgJson.toString());
            imageUrl = imageArr.length() > 0 ? imageArr.getJSONObject(0).getString("url") : "N/A";

            // 3. Build JSON response
            JSONObject result = new JSONObject();
            result.put("name", breedInfo.getString("name"));
            result.put("temperament", breedInfo.optString("temperament", "N/A"));
            result.put("origin", breedInfo.optString("origin", "N/A"));
            result.put("life_span", breedInfo.optString("life_span", "N/A"));
            result.put("image_url", imageUrl);

            // Return JSON to client
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            PrintWriter out = response.getWriter();
            out.print(result.toString());
            out.flush();

            // 4. Log to MongoDB if mobile device
            if (shouldLog) {
                long latency = System.currentTimeMillis() - startTime;
                Document log = new Document("timestamp", Instant.now().toString())
                        .append("breed_queried", breedName)
                        .append("phone_model", deviceModel)
                        .append("user_agent", userAgent != null ? userAgent : "N/A")
                        .append("api_response_status", catApiStatus)
                        .append("latency_ms", latency)
                        .append("returned_name", breedInfo.getString("name"))
                        .append("origin", breedInfo.optString("origin", "N/A"))
                        .append("temperament", breedInfo.optString("temperament", "N/A"))
                        .append("life_span", breedInfo.optString("life_span", "N/A"))
                        .append("image_url", imageUrl);

                logCollection.insertOne(log);
                System.out.println(">>  Logged mobile request.");
            } else {
                System.out.println(">>  Not logging – non-mobile request.");
            }

        } catch (Exception e) {
            // Send error response in case of exceptions
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");
            JSONObject error = new JSONObject();
            error.put("error", e.getMessage());
            response.getWriter().write(error.toString());
        }
    }
}
